<?php

	$idMorador = $_GET['idMorador'];
	$valorMinimo = $_GET['valorMinimo'];
	$valorMaximo = $_GET['valorMaximo'];
	
	echo $idMorador . "<br>";
	echo $valorMinimo . "<br>";
	echo $valorMaximo . "<br>";
	
?>

