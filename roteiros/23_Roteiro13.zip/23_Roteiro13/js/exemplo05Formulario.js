﻿
$(document).ready(function() {
  $('.valores').mask("#.##0,00", {reverse: true});
});
